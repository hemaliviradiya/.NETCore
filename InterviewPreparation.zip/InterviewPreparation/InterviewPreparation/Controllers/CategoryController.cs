﻿using InterviewPreparation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace InterviewPreparation.Controllers
{
    public class CategoryController : Controller
    {
        private InterviewContext In = new InterviewContext();
        // GET: CategoryController
        public ActionResult Index()
        {
            return View(In.Category.ToList());
        }

        private Category GetCategory(int id)
        {
            return In.Category.SingleOrDefault(c => c.CategoryId == id);
        }

        // GET: CategoryController/Details/5
        public ActionResult Details(int id)
        {
            return View(GetCategory(id));
        }

        // GET: CategoryController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CategoryController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]  
        public ActionResult Create(Category newcat)
        {
            try
            {
                Category cd = new Category();
                cd.CategoryId = In.Category.Max(c => c.CategoryId) + 1;
                cd.CategoryName = newcat.CategoryName;

                In.Category.Add(cd); // Use Add method to insert the record.
                In.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoryController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(In.Category.FirstOrDefault(c => c.CategoryId == id));
        }

        // POST: CategoryController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Category updatedCategory)
        {
            try
            {
                // Retrieve the existing category from the database
                Category existingCategory = In.Category.FirstOrDefault(c => c.CategoryId == id);

                if (existingCategory == null)
                {
                    // Handle the case where the category doesn't exist
                    return NotFound();
                }

                // Update the properties of the existing category
                existingCategory.CategoryName = updatedCategory.CategoryName;

                // Save the changes to the database
                In.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoryController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(GetCategory(id));
        }

        // POST: CategoryController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Category categoryToDelete = GetCategory(id);
                if (categoryToDelete == null)
                {
                    // Handle the case where the category doesn't exist
                    return NotFound();
                }

                // Mark the category for deletion
                In.Category.Remove(categoryToDelete);

                // Save the changes to the database
                In.SaveChanges();

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
