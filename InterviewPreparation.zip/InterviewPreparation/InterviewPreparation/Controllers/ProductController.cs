﻿using InterviewPreparation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;

namespace InterviewPreparation.Controllers
{
    public class ProductController : Controller
    {
        private InterviewContext In = new InterviewContext();
        // GET: ProductController
        public ActionResult Index()
        {
            return View(In.Product.ToList());
        }

        private Product GetProduct(int id)
        {
            return In.Product.SingleOrDefault(p => p.ProductId == id);
        }

        // GET: ProductController/Details/5
        public ActionResult Details(int id)
        {
            return View(GetProduct(id));
        }

        // GET: ProductController/Create
        public ActionResult Create()
        {
            List<SelectListItem> ls = new List<SelectListItem>();
            foreach (var ca in In.Category)
            {
                ls.Add(new SelectListItem { Text = ca.CategoryName, Value = ca.CategoryId.ToString() });
            }
            ViewBag.ls = ls;
            return View();
        }

        // POST: ProductController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Product p)
        {
            try
            {
                Product pd = new Product
                {
                    ProductId = In.Product.Max(p => p.ProductId) + 1,
                    ProductName = p.ProductName,
                    CategoryId = p.CategoryId,
                    Price = p.Price,
              
                };
                In.Product.Add(pd);
                In.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ProductController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ProductController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ProductController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
