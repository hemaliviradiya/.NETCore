﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewInterview.Model;
using System.Linq;

namespace NewInterview.Controllers
{
   
    public class CategoriesController : Controller
    {
        private InterviewContext INC = new InterviewContext();
        // GET: CategoriesController
        public ActionResult Index()
        {
            return View(INC.Category.ToList());
        }

        private Category GetCategory(int id)
        {
            return INC.Category.SingleOrDefault(c => c.CategoryId == id);
        }

        // GET: CategoriesController/Details/5
        public ActionResult Details(int id)
        {
            return View(GetCategory(id));
        }

        // GET: CategoriesController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: CategoriesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Category cd)
        {
            try
            {
                Category cv = new Category();
                cv.CategoryId = INC.Category.Max(c => c.CategoryId) + 1;
                cv.CategoryName = cd.CategoryName;
                INC.Category.Add(cv);
                INC.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoriesController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(GetCategory(id));
        }

        // POST: CategoriesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Category cd)
        {
            try
            {
                Category ce = GetCategory(id);
                ce.CategoryName = cd.CategoryName;
                INC.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CategoriesController/Delete/5
        public ActionResult Delete(int id)
        {
            
            return View(GetCategory(id));
        }

        // POST: CategoriesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                Category categoryToDelete = GetCategory(id);
                if (categoryToDelete == null)
                {
                    // Handle the case where the category doesn't exist
                    return NotFound();
                }

                // Mark the category for deletion
                INC.Category.Remove(categoryToDelete);

                // Save the changes to the database
                INC.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
